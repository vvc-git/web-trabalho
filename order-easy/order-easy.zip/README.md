Victor Valle Cunha 20104135
José Daniel Alves do Prado

Nosso sistema é um sistema que gerencia pedidos de um restaurante

Git: https://github.com/vvc-git/web-trabalho
Servidor: http://webtrabalho.victor.valle.vms.ufsc.br/
